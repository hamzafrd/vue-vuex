import { createRouter, createWebHistory } from 'vue-router';
import HomePage from '@/components/HomePageProducts.vue';
import CheckOut from '@/components/CheckOut.vue'

const routes = [
    {
        path: "/",
        component: HomePage
    },
    {
        path: '/checkout',
        component: CheckOut
    },
]
//create router
const router = createRouter({
    history: createWebHistory(),
    routes  // config routes
})

export default router

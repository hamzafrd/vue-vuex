<template>
  <div id="app" class="container mt-5">
    <router-view />
  </div>
</template>
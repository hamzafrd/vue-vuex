<template lang="html">
    <transition name="custom" enter-active-class="animate__animated animate__fadeInDown"
        leave-active-class="animate__animated animate__fadeOutUp">
        <div v-if="sliderStatus">
            <div class="align-items-center" :class="sliderState">
                <label class="font-weight-bold mr-2">Max Price</label>
                <input type="number" class="form-control mx-2" style="width: 60px; text-align: center;" v-model="maxAmount"
                    @change="updateMaxPrice(maxAmount)">
                <input type="range" class="custom-range" min="0" max="100" v-model="maxAmount"
                    @change="updateMaxPrice(maxAmount)">
            </div>
        </div>
    </transition>
</template>
<script>
import { computed } from 'vue';
import { useStore } from 'vuex';

export default {
    name: 'price-slider',
    data() {
        return {
            maxAmount: this.maxPrice
        }
    },
    setup() {
        const store = useStore()

        const maxPrice = store.state.maxPrice
        const updateMaxPrice = (price) => store.commit('setMaxPrice', price)

        const sliderStatus = computed(() => store.state.sliderStatus)
        const sliderState = computed(() => sliderStatus.value ? 'd-flex' : 'd-none')

        return {
            updateMaxPrice,
            sliderState,
            sliderStatus,
            maxPrice
        }
    }
}
</script>
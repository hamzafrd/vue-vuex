<template lang="html">
    <div>
        <h1>IDShop</h1>
        <nav-bar />
        <price-slider />
        <product-list />
    </div>
</template>
<script>
import PriceSlider from './PriceSlider.vue';
import ProductList from './ProductList.vue';
import NavBar from './NavBar.vue'

export default {
    name: "home-page-products",
    components: {
        PriceSlider,
        ProductList,
        NavBar
    },

}
</script>
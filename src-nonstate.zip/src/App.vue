<template>
  <div id="app" class="container mt-5">
    <!-- <CheckOut :cart="cart" :cartTotal="cartTotal" @add="addItem" @remove="removeItem" />
    <product-main :products="products" :cart="cart" :cartQty="cartQty" :cartTotal="cartTotal" :sliderStatus="sliderStatus"
      @add="addItem" @remove="removeItem" @sliderState="toggleSlider" :maxPrice="maxPrice">
    </product-main> -->
    <router-view :products="products" :cart="cart" :cartTotal="cartTotal" :cartQty="cartQty" :sliderStatus="sliderStatus"
      :maxPriceProp="maxPrice" @add="addItem" @remove="removeItem" @sliderState="toggleSlider"
      v-model:maxPriceMain="maxPrice" />
  </div>
</template>

<script>
// import axios from 'axios'

export default {
  name: 'App',
  data: function () {
    return {
      maxPrice: 80,
      products: [],
      cart: [],
      sliderStatus: false,
    }
  },

  mounted: function () {
    // this.$store.dispatch("fetchProducts")
    // fetch('https://hplussport.com/api/products/order/price')
    //   .then(response => response.json())
    //   .then(data => {
    //     this.products = data
    //   });

    // axios
    //   .get(baseUrl)
    //   .then(response => this.products = response.data)
  },

  methods: {
    toggleSlider: function () {
      console.log('slider parent');
      this.sliderStatus = !this.sliderStatus
    },

    addItem: function (product) {
      let productIndex;
      const productExist = this.cart.filter(function (item, index) {
        if (item.product.id == Number(product.id)) {
          productIndex = index
          return true
        } else {
          return false
        }
      })

      if (productExist.length) {
        this.cart[productIndex].qty++
      } else {
        this.cart.push({ product: product, qty: 1 })
      }
    },

    removeItem: function (key) {
      // console.log(key);
      if (this.cart[key].qty > 1) {
        this.cart[key].qty--
      } else {
        this.cart.splice(key, 1)
      }
    },
  },

  //computated itu seperti observe
  computed: {
    cartTotal: function () {
      let sum = 0
      this.cart.forEach((key, index) => {
        const totalPrice = this.cart[index].product.price * this.cart[index].qty
        sum += totalPrice
      })
      return sum;
    },

    cartQty: function () {
      let sum = 0
      this.cart.forEach((key, index) => {
        const qty = this.cart[index].qty
        sum += qty
      })
      return sum
    }
  },
}

</script>

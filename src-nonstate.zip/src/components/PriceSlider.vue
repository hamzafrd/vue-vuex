<template lang="html">
    <transition name="custom" enter-active-class="animate__animated animate__fadeInDown"
        leave-active-class="animate__animated animate__fadeOutUp">
        <div v-if="sliderStatus">
            <div class="align-items-center" :class="sliderState">
                <label class="font-weight-bold mr-2">Max Price</label>
                <input type="number" class="form-control mx-2" style="width: 60px; text-align: center;" v-model="maxAmount"
                    @change="$emit('update:maxPriceSlider', maxAmount)">
                <input type="range" class="custom-range" min="0" max="200" v-model="maxAmount"
                    @change="$emit('update:maxPriceSlider', maxAmount)">
            </div>
        </div>
    </transition>
</template>
<script>
export default {
    name: 'price-slider',
    props: ['sliderStatus', 'maxPriceSlider'],
    data: function () {
        return {
            maxAmount: this.maxPriceSlider,
        }
    },
    computed: {
        sliderState: function () {
            return this.sliderStatus ? 'd-flex' : 'd-none'
        },
    },
}
</script>
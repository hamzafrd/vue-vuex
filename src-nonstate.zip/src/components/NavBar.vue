<template lang="html">
    <div class="navbar navbar-light fixed-top">
        <div class="navbar-text ml-auto d-flex">
            <button class="btn btn-sm btn-outline-success" @click="$emit('toggleSlider')">
                <!-- <i class="fas fa-dollar-sign"></i> -->
                <font-awesome-icon icon="dollar-sign"></font-awesome-icon>
            </button>

            <div class="ml-2" v-if="cart.length >= 0">
                <button class="btn btn-success btn-sm dropdown-toggle" id="dropdownCart" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    <b>Cart :</b>
                    <span class="badge-pill badge-warning">{{ cartQty }}</span>
                    <!-- <i class="fas fa-shopping-cart mx-2"></i> -->
                    <font-awesome-icon icon="shopping-cart"></font-awesome-icon>

                    <price :price="cartTotal"></price>
                </button>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownCart">
                    <div v-for="(item, index) in  cart " :key="index">
                        <div class="dropdown-item-text text-nowrap text-right">
                            <span class="badge badge-pill badge-warning align-text-top mr-1">
                                {{ item.qty }}
                            </span>
                            {{ item.product.name }}
                            <b>
                                <Price :price="item.product.price * item.qty"></Price>
                            </b>
                            <!-- <b>{{ item.product.price * item.qty | currencyFormat }}</b> -->
                            <a href="#" class="badge badge-danger text-white"
                                @click.stop="$emit('toggleDelete', index)">-</a>

                        </div>
                    </div>
                    <router-link class="btn btn-sm btn-outline-info text-dark float-right mr-2" to="/checkout">
                        CheckOut
                    </router-link>

                </div>
            </div>

        </div>
    </div>
</template>
<script>
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome';
import Price from './PriceItem.vue';

export default {
    name: 'nav-bar',

    props: ['cart', 'cartQty', 'cartTotal'],

    components: {
        Price,
        FontAwesomeIcon
    },

}
</script>
<style lang="css"></style>
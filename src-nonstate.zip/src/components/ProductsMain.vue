<template lang="html">
    <div>
        <h1>IDShop</h1>

        <nav-bar :cart="cart" :cartQty="cartQty" :cartTotal="cartTotal" @toggleSlider="sliderParent"
            @toggleDelete="removeItemParent" />
        <price-slider :sliderStatus="sliderStatus" v-model:maxPriceSlider="maxPriceMain"
            @change="$emit('update:maxPrice', maxPriceMain)" />
        <product-list :products="products" :maxPrice="maxPriceMain" @toggleAdd="addItemParent" />
    </div>
</template>
<script>
import PriceSlider from './PriceSlider.vue';
import ProductList from './ProductList.vue';
import NavBar from './NavBar.vue'

export default {
    name: "products-main",
    data: function () {
        return {
            maxPriceMain: this.maxPriceProp
        }
    },
    props: [
        "products",
        "cart",
        "cartQty",
        "cartTotal",
        "sliderStatus",
        "maxPriceProp"
    ],
    components: {
        PriceSlider,
        ProductList,
        NavBar
    },
    methods: {
        sliderParent: function () {
            this.$emit('sliderState')
        },
        addItemParent: function (item) {
            this.$emit('add', item)
        },
        removeItemParent: function (index) {
            this.$emit('remove', index)
        },
    },

}
</script>
<style lang="css"></style>
import { createStore } from "vuex";
import axios from 'axios'
export default createStore({
    state: {
        products: [],
        cart: []
    },

    actions: {
        /** 
         * Better way using Promise
        */

        // fetchProducts() {
        //     return new Promise((resolve, reject) => {
        //         axios.get('https://hplussport.com/api/products/order/price')
        //             .then(response => resolve(response.data))
        //             .catch(e => reject(e))
        //     })
        // }

        /**
         * Proper Way using VueX action
         */
        fetchProducts({ commit }) {
            axios.get('https://hplussport.com/api/products/order/price')
                .then(response => commit("setProductsData", response.data))
                .catch(e => console.log(e))
        }
    },

    mutations: {
        setProductsData(state, productsData) {
            state.products = productsData
        }
    }
})
import { createRouter, createWebHistory } from 'vue-router';
import ProductsMain from '@/components/ProductsMain.vue';
import CheckOut from '@/components/CheckOut.vue'

const routes = [
    {
        path: "/",
        component: ProductsMain
    },
    {
        path: '/checkout',
        component: CheckOut
    },
]
//create router
const router = createRouter({
    history: createWebHistory(),
    routes  // config routes
})

export default router

<template>
  <div id="app" class="container mt-5">
    <h1>IdShop</h1>

    <nav-bar :cart="cart" :cartQty="cartQty" :cartTotal="cartTotal" @toggleSlider="toggleSlider"
      @toggleDelete="removeItem"></nav-bar>
    <price-slider :sliderStatus="sliderStatus" v-model:maxPriceSlider="maxPrice"></price-slider>
    <product-list :products="products" :maxPrice="maxPrice" @toggleAdd="addItem"></product-list>
  </div>
</template>

<script>
import PriceSlider from './components/PriceSlider.vue';
import ProductList from './components/ProductList.vue';
import NavBar from './components/NavBar.vue'
export default {
  name: 'App',

  data: function () {
    return {
      maxPrice: 50,
      products: [],
      cart: [],
      sliderStatus: false,
    }
  },

  components: {
    ProductList,
    PriceSlider,
    NavBar,
  },

  mounted: function () {
    fetch('https://hplussport.com/api/products/order/price')
      .then(response => response.json())
      .then(data => {
        this.products = data
      });
  },

  methods: {
    toggleSlider: function () {
      this.sliderStatus = !this.sliderStatus
    },

    addItem: function (product) {
      console.log('test');
      let productIndex;
      const productExist = this.cart.filter(function (item, index) {
        if (item.product.id == Number(product.id)) {
          productIndex = index
          return true
        } else {
          return false
        }
      })

      if (productExist.length) {
        this.cart[productIndex].qty++
      } else {
        this.cart.push({ product: product, qty: 1 })
      }
    },

    removeItem: function (key) {
      console.log(key);
      if (this.cart[key].qty > 1) {
        this.cart[key].qty--
      } else {
        this.cart.splice(key, 1)
      }
    },
  },

  //computated itu seperti observe
  computed: {
    cartTotal: function () {
      let sum = 0
      this.cart.forEach((key, index) => {
        const totalPrice = this.cart[index].product.price * this.cart[index].qty
        sum += totalPrice
      })
      return sum;
    },

    cartQty: function () {
      let sum = 0
      this.cart.forEach((key, index) => {
        const qty = this.cart[index].qty
        sum += qty
      })
      return sum
    }
  },
}

</script>

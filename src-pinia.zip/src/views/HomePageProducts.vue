<template lang="html">
    <div>
        <price-slider />
        <product-list />
    </div>
</template>
<script setup>
import PriceSlider from '@/components/PriceSlider.vue';
import ProductList from '@/components/ProductList.vue';


</script>